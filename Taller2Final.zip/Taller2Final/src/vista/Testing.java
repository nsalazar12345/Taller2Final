
package vista;

import controlador.ProductoController;
import dao.ProductoDAO;
import modelo.Producto;



/**
 *
 * @author salaz
 */
public class Testing {
    
    public static void main(String[] args) {
        Producto p = new Producto();
        ProductoDAO pd = new ProductoDAO();
        VistaProducto vp = new VistaProducto(); 
        ProductoController pc = new ProductoController(p,vp,pd);
        vp.setVisible(true);
        
    }  
}
