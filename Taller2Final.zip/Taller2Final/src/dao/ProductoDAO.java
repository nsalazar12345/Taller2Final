package dao;

/**
 *
 * @author salaz
 */

import com.mysql.jdbc.PreparedStatement;
import conexion.Conector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modelo.Producto;
import vista.VistaProducto;


public class ProductoDAO extends Conector {
    
    //CONEXIÓN Y EJECUCIÓN DE QUERY SQL 
    private Connection con = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    Producto p = new Producto();
    
    
    public ProductoDAO() {
    }
      
    //MÉTODO PARA INGRESAR UN PRODUCTO
    public boolean ingresarProducto(Producto p) {
        boolean resp = false; 
        try {
            String sql = "INSERT INTO  producto(nombre, precio, descripcion) values(?,?,?)";
            con = Conector.iniciarConexion(); 
            ps = (PreparedStatement) con.prepareStatement(sql); 
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getPrecio());
            ps.setString(3, p.getDescripcion());

            resp = true; 
            
        } catch (SQLException e) {
            System.out.println("ERROR SQL");
        }
        return resp; 
    }
    
       public boolean editarProducto(Producto p) {
        boolean resp = false; 
        try {
            String sql = "UPDATE producto(nombre=?, precio=?, descripcion=?) where codigo=?";
            con = Conector.iniciarConexion(); 
            ps = (PreparedStatement) con.prepareStatement(sql); 
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getPrecio());
            ps.setString(3, p.getDescripcion());
            ps.setInt(4, p.getCodigo());
            ps.execute();
            

            resp = true; 
            
        } catch (SQLException e) {
            System.out.println("ERROR SQL");
            System.out.println(e);
        }
        return resp; 
        }
    
    
    
    
    
    
    /*MÉTODO PARA EDITAR PRODUCTOS
    public boolean editarProducto(String nombre, int codigo, String precio, String descripcion) {
        boolean resp = false;
        try {
            con = Conector.iniciarConexion();
            statement = con.createStatement();
            String sql = "UPDATE producto "
                    + " SET nombre = '" + nombre + "' precio='" + precio + "' descripcion='" + descripcion
                    + "' WHERE codigo='" + codigo + "'";
            statement.executeUpdate(sql);
            resp = true;
            statement.close();
            con.close();
        } catch (SQLException e) {
            System.out.println("ERROR SQL");
        }
        return resp;
    }
    */
       
       
    
        
    public boolean eliminarProducto(Producto p) {
        boolean resp = false; 
        try {
            String sql = "DELETE FROM producto WHERE codigo=?";
            con = Conector.iniciarConexion(); 
            ps = (PreparedStatement) con.prepareStatement(sql);
            ps.setInt(1, p.getCodigo());
            ps.execute();
            

            resp = true; 
            
        } catch (SQLException e) {
            System.out.println("ERROR SQL");
            System.out.println(e);
        }
        return resp; 
    }
    
    public boolean verProductos(Producto p) {
        //boolean resp = false; 
        try {
            String sql = "SELECT * FROM producto WHERE codigo=?";
            con = Conector.iniciarConexion(); 
            ps = (PreparedStatement) con.prepareStatement(sql);
            ps.setInt(1, p.getCodigo());
            rs = ps.executeQuery();
            if(rs.next()){
                p.setNombre(rs.getString("nombre"));
                p.setCodigo(Integer.parseInt(rs.getString("codigo")));
                p.setPrecio(rs.getString("precio"));
                p.setDescripcion(rs.getString("descripcion"));
                return true;
            
            }
            return false;

           // resp = true; 
            
        } catch (SQLException e) {
            System.out.println("ERROR SQL");
            System.out.println(e);
        }
        return false; 
    }
    
    
    
     

    
   /*MÉTODO PARA ELIMINAR UN PRODUCTO
    public boolean eliminarProducto(int codigo) {
        boolean resp = false;
        try {
            con = Conector.iniciarConexion();
            statement = con.createStatement();
            String sql = "DELETE FROM producto WHERE codigo='" + codigo + "'"; 
            statement.executeUpdate(sql);
            resp = true;
            statement.close();
        } catch (SQLException e) {
            System.out.println("ERROR SQL");
        }
        return resp;
    }*/


   /* public ArrayList verProductos() {
        ArrayList <Producto> productos = new ArrayList<>(); //CREACIÓN DEL ARRAYLIST QUE ALMACENARÁ LOS DATOS DE LA BD
        try {
            con = Conector.iniciarConexion();
            statement = con.createStatement();
            String sql = "SELECT * FROM producto"; 
            resultSet = statement.executeQuery(sql); //SE OBTIENEN LOS DATOS DE LA BD
            while (resultSet.next()) { 
                Producto p = new Producto(); //CREACIÓN DEL PRODUCTO 
                p.setNombre(resultSet.getString("Nombre")); //ASIGNACIÓN DEL ATRIBUTO 'Nombre'                
                p.setCodigo(Integer.parseInt(resultSet.getString("Codigo"))); //ASIGNACIÓN DEL ATRIBUTO 'Codigo'
                p.setPrecio(resultSet.getString("Precio")); //ASIGNACIÓN DEL ATRIBUTO 'Precio'
                p.setDescripcion(resultSet.getString("Descripción")); //ASIGNACIÓN DEL ATRIBUTO 'Descripcion'
                productos.add(p); //SE AGREGA EL OBJETO NUEVO A LA LISTA
               
            }
            System.out.println("sql"+sql);
            statement.close();
            con.close();
        } catch (SQLException e) {
            System.out.println("ERROR SQL");
        }
        return productos; 

    }*/
}
