
package modelo;

/**
 *
 * @author salaz
 */
public class Producto {
    private String nombre;
    private int codigo;
    private String precio;
    private String descripcion;

    public Producto() {
    }

    public Producto(String nombre, String precio, String descripcion) {
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    @Override
    public String toString() {
        String txt = "Nombre: " + this.getNombre()
                + " - Precio: " + this.getPrecio()
                + " - Descripcion: " + this.getDescripcion();
        return txt;
    }
    
}
