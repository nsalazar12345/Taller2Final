package controlador;

/**
 *
 * @author salaz
 */

import dao.ProductoDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.Producto;
import vista.VistaProducto;

public class ProductoController implements ActionListener {
  
    private Producto p;
    private VistaProducto vp;
    private ProductoDAO pd;
    

    public ProductoController(Producto p, VistaProducto vp, ProductoDAO pd) {
        this.p = p;
        this.vp = vp;
        this.pd = pd;
        this.vp.ingresarP.addActionListener(this);
        this.vp.editarP.addActionListener(this);
        this.vp.eliminarP.addActionListener(this);
        this.vp.verP.addActionListener(this);   
    }
    
  
    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        
        if (comando == "ingresarP") {
            p.setNombre(vp.txtNombre.getText());
            p.setPrecio(vp.txtPrecio.getText());
            p.setDescripcion(vp.txtDescripcion.getText());
            if(pd.ingresarProducto(p)){
                JOptionPane.showMessageDialog(null,"INGRESO EXITOSO");
                limpiar();
            }else{
                JOptionPane.showMessageDialog(null, "NO FUE POSINLE EL INGRESO");
                limpiar();
            }
        }
        if(comando == "editarP") {
            p.setCodigo(Integer.parseInt(vp.txtCodigo.getText()));
            p.setNombre(vp.txtNombre.getText());
            p.setPrecio(vp.txtPrecio.getText());
            p.setDescripcion(vp.txtDescripcion.getText());
            if(pd.editarProducto(p)){
                JOptionPane.showMessageDialog(null,"EDICIÓN EXITOSA");
                limpiar();
            }else{
               JOptionPane.showMessageDialog(null, "NO FUE POSIBLE EDITAR");
               limpiar();
            }
               
        }
        
        if (comando == "verP"){
            p.setCodigo(Integer.parseInt(vp.txtCodigo.getText()));
            if(pd.verProductos(p)){
                vp.txtNombre.setText(p.getNombre());
                vp.txtPrecio.setText(p.getPrecio());
                vp.txtDescripcion.setText(p.getDescripcion());  
            }else{
                JOptionPane.showMessageDialog(null, "NO FUE POSIBLE ELIMINAR");
                limpiar();
            }
        }
    }    
        
        
    
    public void limpiar(){
        vp.txtNombre.setText(null);
        vp.txtPrecio.setText(null);
        vp.txtDescripcion.setText(null);   
    }
        
}
