package conexion;

/**
 *
 * @author salaz
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conector {
      public static Connection iniciarConexion() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String serv = "jdbc:mysql://localhost:3306/inventario";
            String user = "root";
            String pass = "";
            con = DriverManager.getConnection(serv, user, pass);
        } catch (ClassNotFoundException e) {
            System.out.println("ERROR BD");
        } catch (SQLException e) {
            System.out.println("ERROR SQL");
        } catch (Exception e) {
            System.out.println("ERROR");
        }
        return con;
        
    }
    
}
